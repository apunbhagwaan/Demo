﻿using System;
using System.Runtime.Serialization;

namespace PMS_AdoConArch_Demo
{
    [Serializable]
    internal class PMS_Exception : Exception
    {
        public PMS_Exception()
        {
        }

        public PMS_Exception(string message) : base(message)
        {
        }

        public PMS_Exception(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected PMS_Exception(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}